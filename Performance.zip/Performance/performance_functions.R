suppressMessages(library(dplyr))
suppressMessages(library(randomForest))
suppressMessages(library(GGally))
suppressMessages(library(RColorBrewer))
suppressMessages(library(plyr))
suppressMessages(library(gridExtra))
suppressMessages(library(reshape2))
suppressMessages(library(lemon))
suppressMessages(library(grid))

### Calculates the error between observed and predicted feature
### Input: y (observed y), ypred (predicted y) , type (type of error: "Absolute", "Residual" or "Log")
calculate_error <- function(y, ypred, type="Absolute"){
  if (type == "Absolute") {
    error <- abs(y-ypred)
  }
  if (type == "Residual"){
    error <- y-ypred
  }
  #Adds 1 for the visualization to start at 0
  if (type == "Log"){
    error <- log(1+abs(y-ypred))
  }
  return (error)  
}  

bincounter <- function(train_data, test_data, feature, quantil_break=c(0.1, 0.35, 0.65, 0.9)){
  
  all_data <- rbind(train_data, test_data)
  
  if(!is.factor(all_data[[feature]])){
    #breaks <- c(min(all_data[[feature]]),quantile(unique(all_data[[feature]]),probs = quantil_break), max(all_data[[feature]])+1)
    result_all <- bin_data(all_data, feature, return_breaks = TRUE, quantil_break=quantil_break)
    train_data <- bin_data(train_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(train_data) <- result_all$names
    test_data <- bin_data(test_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(test_data) <- result_all$names
    
    #Eliminate null bins
    train_data<-train_data[sapply(train_data, function(x) dim(x)[1]) > 0]
    test_data<-test_data[sapply(test_data, function(x) dim(x)[1]) > 0]
    # 
    train_data <- melt(train_data, measure.vars=feature)
    test_data <- melt(test_data, measure.vars=feature)
    all_data <- melt(bin_data(all_data, feature, quantil_break=quantil_break), measure.vars=feature)
    train_data[[feature]]<- factor(train_data[["L1"]], levels=result_all$names) 
    test_data[[feature]] <- factor(test_data[["L1"]], levels=result_all$names)
    all_data[[feature]] <- factor(all_data[["L1"]])
    
  }
  return(merge(merge(count(test_data, vars=feature), count(train_data, vars=feature), by=feature, suffixes=c(".test", ".train")), count(all_data, vars=feature), by=feature))
}

#############
## Creates a data frame with feature values, models error and models predictions
## Format: variable1|...|variablen| ypred_Model1| error_Model1|...|ypred_ModelM |error_ModelM
## Size: n_data_points x (n_features + 2 x M)
## Input: data (data set with features, predictor and model predictions), models (list of models names), feature_y(predictor name), type (error type. See )
##        type (error type:"Absolute", "Residual" or "Log")
all_model_data <- function (data, models, feature_y, type="Absolute"){
  y <- data[[feature_y]]
  x <- data[,!(names(data) %in% rbind(feature_y, models))]
  if (is.list(models)!= TRUE) models <- list(models) #If single model
  for (mod in models){
    ypred <- data[mod]
    x[paste0("pred",mod)] <- ypred
    x[paste0("error",mod)] <- calculate_error(y, ypred, type)
  }
  return (x)
}

#############
## Creates a data frame with feature values, SINGLE model error and model prediction
## Format: variable1|...|variablen| ypred| error
## Size: n_data_points x (n_features + 2)
## Input: data (data set with features and predictor), model (model prediction)
##        type (error type:"Absolute", "Residual" or "Log")
single_model_data <- function (data, model, feature_y, type="Absolute"){
  y <- data[[feature_y]]
  x <- data[,names(data) != feature_y]
  ypred <- model
  x$pred <- ypred
  x$error <- calculate_error(y, ypred, type)
  return (x)
}

#############
## Bins data in respect to values of a predictor variable
## Input: dataset (data set of type single_model_data() or all_model_data()), feature_x (name of predictor to bin values), 
##        nquant, size, quantil_break, breaks, nround (rounding digits), for_evaluation (if FALSE deletes empty bins)
## Options: nquant - choose number of bins equally frequent
##        : size - choose number of instances per bin
##        : quantil_break - choose quantile values
##        : breaks - choose break points
## return_breaks: if TRUE, gives break points for train and test set (to be used in evaluation only) as well as the bins names
## Output: List of dataframes with indexes informing on the limits of each bin for the predictor variable
bin_data <- function(dataset, feature_x, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, nround=2, for_evaluation=FALSE, return_breaks=FALSE){
  dataset <- dataset[order(dataset[[feature_x]]),]
  
  if (! is.null(size)){
    cutdata <- split(dataset, ceiling(seq_along(dataset[[feature_x]])/size))
  }
  else if(! is.null(nquant)){
    cutdata <- split(dataset, floor(nquant*seq.int(0, nrow(dataset) -1 )/ nrow(dataset)))
    
  }
  else{
    cutdata <- list()
    if (is.null(breaks))  breaks <- c(min(dataset[[feature_x]]),quantile(unique(dataset[[feature_x]]),probs = quantil_break), max(dataset[[feature_x]])+1)
    for (i in 1:(length(breaks)-1)){
      cutdata[[i]]<-data.frame()
      for (j in 1:nrow(dataset)){
        if (dataset[[feature_x]][j]>=breaks[[i]]&&dataset[[feature_x]][j]<breaks[[i+1]]){
          cutdata[[i]]<-rbind(cutdata[[i]], dataset[j,])
        }
      }
    }
  }
  
  if(isFALSE(for_evaluation)){
    # Check the existence of null bins. Calculate min and max of each bin
    cutdata<-cutdata[sapply(cutdata, function(x) dim(x)[1]) > 0]
    limit <- data.frame(featmax=0, featmin=0)
    for (i in 1:length(cutdata)) {
      limit[i,] <- c(max(cutdata[[i]][[feature_x]]), min(cutdata[[i]][[feature_x]]))
    }
    
    # Name bins with [lower limit - higher limit]. Increases nround if bins have same name due to few rounding numbers (ex [0-0], [0-0] --> [0-0.1],[0.1-0.2])
    repeat{
      names(cutdata)<-paste0("[",round(limit$featmin,nround), "-", round(limit$featmax,nround),"]")
      nround <- nround+1
      if (length(names(cutdata))==length(unique(names(cutdata)))){
        break
      }
    }
  }
  
  if(isTRUE(return_breaks)){
    result <- list(breaks=c(limit$featmin, tail(limit$featmax, n=1)+1), names = names(cutdata))
    return(result)
  }else{
    return (cutdata)}
}  


#############
## PARALELL ERROR PLOT
## Input: data (data set of type single_model_data()), colour (colour of top errors), alphaLines (if NULL have predefined values), type (error type), 
##        scale (use scale argument for ggparcoord), option, breakpoint (quantile of probability for top errors)
## Options: A: plots error with increasing saturation
##        : B: plots breakpoint low errors in grey, and top in colour
## Notes: Automatic alphaLines of 0.7 for data set with less than 1000 data instances, of 0.1 if more 
pep <- function(data, colour="red", alphaLines=NULL, type="Absolute", scale="uniminmax", option="B", breakpoint=0.9){
  ord<-data[order(data[["error"]]),]
  h<-quantile(unique(data[["error"]]),probs = breakpoint)[[1]]
  if (is.null(alphaLines)){
    if (nrow(data)>1000){
      alphaLines <- 0.1
    }else{
        alphaLines <- 0.7
      }
  }
  
  
  if (option=="A"){
    
    ggplot <- ggparcoord(ord, columns=1:(ncol(data)-2), groupColumn='error', alphaLines=alphaLines, shadeBox='white', scale=scale) + 
      scale_colour_gradient2(low="gray90", mid="gray85", high = colour, midpoint=h) + ylab(paste0("Feature Values - mode ",scale)) + xlab("Features") +
      theme(panel.background = element_rect(fill='gray95', colour="gray95"), panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "white"), 
            panel.grid.minor = element_line(linetype = 'solid',colour = "white"))
  }
  
  if (option=="B"){
    
    ord$higher <- ifelse(ord$error >= h, paste0("Top ", (1-breakpoint)*100,"%"), paste0("Lower ", breakpoint*100,"%"))
    ggplot <- ggparcoord(ord, columns=1:(ncol(data)-2), groupColumn='higher', shadeBox='white', alpha=alphaLines, scale=scale) + 
      xlab("Features") + scale_color_manual(name="Error", values =c("gray70", "red")) +
      guides(colour = guide_legend(override.aes = list(alpha=1))) +
      ylab(paste0("Feature Values - mode ", scale))
  }
  
  return (ggplot)
}


#############
## ERROR DISTRIBUTION PLOT (EDP)
## Input: data (data set of type single_model_data()), feature (feature of interest, x-axis), 
##        bin_data options (nquant, size, quantil_break, breaks), nround (rounding digits), 
##        type (error type), jitter
edp <- function(data,  feature, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, jitter=FALSE, nround=2, type="Absolute"){
  
  errorplot <- ggplot() +
    xlab(feature) + ylab(paste0(type, " error distribution"))
  
  # EDP for nominal feature (does not need partition)
  if(is.factor(data[[feature]])){
    freq <- plyr::count(factor(data[[feature]]))
    nbins <- length(freq[[1]])
    errorplot <- errorplot + geom_boxplot(data=data, aes(x=data[[feature]], y=error)) + scale_x_discrete(labels=paste0(freq[[1]],"\n(",round(freq[["freq"]]*100/nrow(data),2),"% - ",freq[["freq"]], ")")) + geom_hline(yintercept=median(data[["error"]]), linetype="dashed")
    if (isTRUE(jitter)){ 
      errorplot<-errorplot + geom_jitter(data=data, aes(x=data[[feature]], y=error), alpha= 0.3)
    }
  }
  
  # EDP for numerical feature (with partition of data set into bins)
  else{
    cutdata <- bin_data(data, feature, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL)
    nbins <- length(cutdata)
    var <- melt(cutdata, id.vars=feature, measure.vars="error", value.name="error")
    freqcount <- plyr::count(factor(var$L1))[[2]]
    freq <- round(freqcount*100/nrow(data), 2)
    var$L1 <- factor(var$L1, levels=names(cutdata))
    
    errorplot <- errorplot + geom_boxplot(data=var, aes(x=L1, y=error))+ 
      scale_x_discrete(labels=paste0(names(cutdata), "\n(", freq, "% - ", freqcount, ")")) +
      geom_hline(yintercept=median(data[["error"]]), linetype="dashed")
    
    if (isTRUE(jitter)){ 
      errorplot <- errorplot + geom_jitter(data=var, aes(x=L1, y=error), alpha= 0.3)
    }
  }
  
  # Adds comparison plot with all data
  allerror <- ggplot()+ xlab(" ") + geom_boxplot(data=data, aes(x='all', y=error)) + scale_x_discrete(labels=paste0("All data \n(100% - ",nrow(data), ")")) + theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank())  + geom_hline(yintercept=median(data[["error"]]), linetype="dashed") 
  plot <- grid.arrange(errorplot, allerror, ncol=2, widths=c(nbins, 1))
  return(plot)
}

#############
## MULTIPLE MODEL ERROR DISTRIBUTION PLOT
## Input: data (data set of type all_model_data()), feature (feature of interest, x-axis), mod_names (list of model names)
##        bin_data options (nquant, size, quantil_break, breaks), nround (rounding digits), 
##        type (error type), jitter
medp <- function(data, feature, mod_names, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, nround=2, type="Absolute"){
  
  median_models <- sapply(data[paste0("error",mod_names)], median)
  errorplot <- ggplot() +
    xlab(feature) + ylab(paste0(type, " error distribution"))
  
  #For categorical data
  if(is.factor(data[[feature]])){
    freq <- plyr::count(factor(data[[feature]]))
    nbins <- length(freq[[1]])
    
    var <- melt(data, id.vars=feature, measure.vars=paste0("error",mod_names), variable.name="model", value.name="error")
    
    errorplot <- errorplot + geom_boxplot(data=var, aes_string(x=feature, y="error", fill="model")) + 
      scale_x_discrete(labels=paste0(freq[[1]],"\n(",round(freq[["freq"]]*100/nrow(data),2),"% - ",freq[["freq"]], ")")) +
      geom_hline(aes(yintercept=median_models, color=levels(factor(median_models))), linetype="dashed") + guides(color=FALSE, fill=FALSE)
  
    } #For numerical data
  else{
    cutdata <- bin_data(data, feature, nquant, size, quantil_break)
    nbins <- length(cutdata)
    var <- melt(cutdata, id.vars=feature, measure.vars=paste0("error",mod_names), variable.name="model", value.name="error")
    freqcount <- plyr::count(var$L1)[[2]]/length(mod_names)
    freq <- round(freqcount*100/(nrow(data)))
    var$L1 <- factor(var$L1, levels=names(cutdata))   #otherwise the order plotted will change
    
    errorplot<- errorplot + geom_boxplot(data=var, aes(x=factor(L1), y=error, fill=model)) +
      scale_x_discrete(labels=paste0(names(cutdata), "\n(",  freq, "% - ", freqcount, ")")) +
      geom_hline(aes(yintercept=median_models, color=levels(factor(median_models))), linetype="dashed") + guides(color=FALSE, fill=FALSE)
  }
  
  
  # Add distribution for all data
  allerror <- ggplot()+ xlab(" ") + geom_boxplot(data=var, aes(x='all', y=error, fill=model)) + 
    scale_fill_discrete(name= "Models", labels=mod_names)+
    scale_x_discrete(labels=paste0("All data \n(100% - ",nrow(data), ")")) + 
    theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank())  + 
    geom_hline(aes(yintercept=median_models, color=levels(factor(median_models))), linetype="dashed") + guides(color=FALSE) 
  
  plot <- grid.arrange(errorplot, allerror, ncol=2, widths=c(nbins, 1.8))
  
  return(plot)
}

#############
## BIVARIATE MULTIPLE MODEL ERROR DISTRIBUTION PLOT
## Input: data (data set of type all_model_data()), feature_list (list of features - first is the x axis, second has the bins as the conditioning)
##        mod_names (list of model names), quantil_break,
##        nround (rounding digits), type (error type),
##        option (type of data without conditioning to show in first facet), ncols (number of columns in final plot)
## Option: 1 - Shows Model Performance Comparison Plot of 1rst variable in feature_list 
##         2 - Shows Model Performance Comparison Plot of 2nd variable in feature_list 
##         3 - Shows Model Performance Comparison Plot without conditioning
biv_medp <- function(data, feature_list, mod_names, quantil_break=c(0.1, 0.35, 0.65, 0.9), nround=2, type="Absolute", option=3, ncols=3){
  
  median_models <- sapply(data[paste0("error",mod_names)], median)
  
  #Partition of the data for both features
  if(is.factor(data[[feature_list[[1]]]])){
    var <- melt(data, id.vars=feature_list, measure.vars=paste0("error",mod_names), variable.name="model", value.name="error")
    
  } else{
    cutdata <- bin_data(data, feature_list[[1]], quantil_break=quantil_break)
    var <- melt(cutdata, id.vars=feature_list, measure.vars=paste0("error",mod_names), variable.name="model", value.name="error")
    var[[feature_list[[1]]]]<-factor(var[["L1"]], levels=names(cutdata))
    var["L1"]<-NULL
  }
  
  if(!is.factor(data[[feature_list[[2]]]])){
    cutdata <- bin_data(var, feature_list[[2]], quantil_break=quantil_break)
    var <- melt(cutdata, id.vars=c("error","model", feature_list))
    var[[feature_list[[2]]]] <- factor(var[["L1"]], levels=names(cutdata))
    var["L1"] <- NULL 
  }
  
  # Names bins of variable 2 as "variable2 = [min bin, max bin]"
  var[[feature_list[[2]]]]<-mapvalues(var[[feature_list[[2]]]], from = levels(var[[feature_list[[2]]]]), to = paste0(feature_list[[2]], " = ", levels(var[[feature_list[[2]]]])))
  
  # Frequency of each bin
  count_var <- plyr::count(var, feature_list)
  count_var$freq <- count_var$freq/length(mod_names)
  var<-merge(var,count_var)
  var$median <- median_models[var$model]
  
  if(nlevels(var[[feature_list[[2]]]]) >= ncols){
    var$feature2 <- factor(var[[feature_list[[2]]]], levels=c(" ", levels(var[[feature_list[[2]]]])))  #Creates free facet for plotting the all data edp
  
  }else {var$feature2 <- var[[feature_list[[2]]]]}
  
  errorplot <- ggplot(data=var, aes_string(x=feature_list[1], y="error", fill="model")) + geom_boxplot() + 
    #geom_text(aes(label=paste0(freq," (",round(100*var$freq/nrow(data),2),"%)"), y=0-max(var$error)/15), vjust=1, size=3) +
    geom_hline(aes(yintercept=median, color=model), linetype="dashed") +
    guides(color=FALSE)+
    scale_fill_discrete(name= "Models", labels=mod_names) + theme(legend.position="bottom")+
    geom_text(data=unique(var[c(feature_list[[1]], "feature2", "freq")]), aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), fill=NULL, y=0-max(var$error)/15), vjust=1, size=3) +
    facet_wrap(~feature2, ncol=ncols, drop=FALSE, scales='free') +
    geom_blank(aes(y=max(var$error))) +
    theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank())
  
 
  guide <- g_legend(errorplot)
  errorplot <- errorplot + guides(fill=FALSE, color=FALSE)
  errorplot <- ggplotGrob(errorplot)
  
  if(nlevels(var[[feature_list[[2]]]]) >= ncols){
  rm_grobs <- errorplot$layout$name %in% c("panel-1-1",  "strip-t-1-1")  #to remove first empty facet
  errorplot$grobs[rm_grobs] <- NULL
  errorplot$layout <- errorplot$layout[!rm_grobs, ]
  }
  
  if(option==3){
    plot1 <- ggplot(data=var, aes(x='All data', y=error, fill=model)) + geom_boxplot() +
      geom_text(data = data.frame("tot"=nrow(data)), aes(label=paste0(tot," (100%)"), fill=NULL, y=0-max(var$error)/15), vjust=1, size=3) +
      geom_hline(aes(yintercept=median, color=model), linetype="dashed") + guides(color=FALSE, fill=FALSE) +
      theme(axis.title.x=element_blank(), axis.title.y = element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~"All data") +
      geom_blank(aes(y=max(var$error)))
  }else{
    var$freq<-NULL
    fcount<-plyr::count(var, feature_list[option])
    fcount$freq <- fcount[["freq"]]/length(mod_names)
    var<-merge(var,fcount)
    
    plot1 <- ggplot(data=var, aes_string(x=feature_list[option], y="error", fill="model")) + geom_boxplot() +
      geom_text(aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), y=0-max(var$error)/15), vjust=1, size=3) +
      geom_hline(aes(yintercept=median, color=model), linetype="dashed") +
      guides(color=FALSE, fill=FALSE) +
      theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~"All data")
  }
  
  
  prop <- 5 #proportion to display of guide
  nrows <- (nlevels(var[[feature_list[[2]]]])) %/% ncols + 1
  
  if (nlevels(var[[feature_list[[2]]]])%%ncols!=0){
    mat <- rbind(rep(c(3), ncols),
                 matrix(c(rep(c(2), prop),
                          rep(c(1), prop*(nrows*ncols-1))), ncol=ncols))
    
  }else{
    mat <- matrix(c(2, rep(c(1), nrows*ncols-2), 3), ncol=ncols)
  }
  
  gtable <- arrangeGrob(errorplot, plot1, guide, layout_matrix=mat, left=paste0(type, " error distribution"), bottom=feature_list[[1]])
  
  return (gtable)
  
}

#############
## BIVARIATE/TRIVARIATE ERROR DISTRIBUTION PLOT
## Input: data (data set of type single_model_data()), feature_list (list of features - first is the x axis, second has the bins as the conditioning)
##        quantil_break, nround (rounding digits), type (error type),
##        option (type of data without conditioning to show in first facet),
##        mode (wrap or grid), ncols (number of columns in final plot)
## Option: 1 - Shows EDP of 1rst variable in feature_list 
##         2 - Shows EDP of 2nd variable in feature_list 
##         "All" - Shows total error distribution
## Mode (only for 3 variables): grid (matrix type; plots all combinations, even if empty; without comparison plot)
##                            : wrap (only plots existing combinations; single plots juxtaposed; with comparison plot)
multiple_edp <- function(data, feature_list, quantil_break=c(0.1, 0.35, 0.65, 0.9), nround=2, type="Absolute", option="All", mode="grid", ncols=2){
  
  var <- melt(data, id.vars=feature_list, measure.vars="error", value.name="error")
  var["variable"] <- NULL
  
  for (f in 1:length(feature_list)){
    if(!is.factor(data[[feature_list[[f]]]])){
      cutdata <- bin_data(var, feature_list[[f]], quantil_break=quantil_break)
      var <- melt(cutdata, id.vars=feature_list, measure.vars="error", value.name="error")
      var[[feature_list[[f]]]]<-factor(var[["L1"]], levels=names(cutdata))
      var[c("L1", "variable")]<-NULL
    }
    if (f != 1){
      var[[feature_list[[f]]]]<-mapvalues(var[[feature_list[[f]]]], from = levels(var[[feature_list[[f]]]]), to = paste0(feature_list[[f]], " = ", levels(var[[feature_list[[f]]]])))
    }
  }
  
  var<-merge(var,plyr::count(var, feature_list))
  var$median <- median(data[["error"]])
  
  if ((nlevels(var[[feature_list[[2]]]]) >= ncols) & (mode == "wrap" || length(feature_list)==2)){
    #Fake point to allow plotting comparison graph
    var[[feature_list[[2]]]] <- factor(var[[feature_list[[2]]]], levels=c(" ", levels(var[[feature_list[[2]]]]))) 
    var <- rbind(var, var[1,])
    var[[feature_list[[2]]]][nrow(var)] <- " "
  }
  
  
  errorplot <- ggplot(data=var, aes_string(x=feature_list[1], y="error")) + geom_boxplot() +
    geom_text(data=unique(var[c(feature_list, "freq")]), aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
    #geom_text(aes(label=paste0(freq," (",round(100*var$freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
    geom_hline(aes(yintercept=median), linetype="dashed")
  
  if (mode == "grid"){
    gtable <- errorplot + facet_grid(feature_list[-1]) + ylab(paste0(type, " error distribution"))
    
  }else if (mode == "wrap" || length(feature_list)==2){
    
    errorplot <- errorplot + facet_wrap(feature_list[-1], ncol=ncols, drop=TRUE, scales='free') + 
      geom_blank(aes(y=max(var$error))) +
      theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank())
    
    #Eliminate 1rst fake plot and substitute by one for comparison
    errorplot <- ggplotGrob(errorplot)
    if (nlevels(var[[feature_list[[2]]]]) >= ncols){
    rm_grobs <- errorplot$layout$name %in% c("panel-1-1",  "strip-t-1-1", "axis-l-1-1", "axis-b-1-1", "axis-r-1-1")
    errorplot$grobs[rm_grobs] <- NULL
    errorplot$layout <- errorplot$layout[!rm_grobs, ]
    var<-var[-nrow(var),]
    }
    
    ext = ifelse(length(feature_list)==2, "", " \n ")
    
    #Plot Comparison Facet
    if(option=='All'){
      plot1 <- ggplot(data=var, aes(x='All data', y=error)) + geom_boxplot() +
        geom_text(data = data.frame("tot"=nrow(data)), aes(label=paste0(tot," (100%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        #geom_text(aes(label=paste0(nrow(data)," (100%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        geom_hline(aes(yintercept=median), linetype="dashed") +
        theme(axis.title.x=element_blank(), axis.title.y = element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~paste0(ext, "All data", ext)) +
        geom_blank(aes(y=max(var$error)))
      
    }else{
      
      var$freq<-NULL
      var<-merge(var,plyr::count(var, feature_list[option]))
      
    plot1 <- ggplot(data=var, aes_string(x=feature_list[option], y="error")) + geom_boxplot() +
        geom_text(data=unique(var[c(feature_list[option], "freq")]), aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        #geom_text(aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        geom_hline(aes(yintercept=median), linetype="dashed") +
        theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~paste0(ext, "All data", ext))
    }
    
    nrows <- (nrow(plyr::count(var, feature_list[-1]))-1) %/% ncols + 1
    mat <- matrix(c(2, rep(c(1), nrows*ncols-1)), ncol=ncols)
    gtable <- arrangeGrob(errorplot, plot1, layout_matrix=mat, left=paste0(type, " error distribution"), bottom=feature_list[[1]])
  }
  return (gtable)
}

#############
## EDP EVALUATION
## Input: train_data (data set of type single_model_data()), test_data (data set of type single_model_data()), 
##        feature (feature of interest, x-axis), quantil_break, error_type
evaluation_edp <- function(train_data, test_data, feature, quantil_break=c(0.1, 0.35, 0.65, 0.9), error_type){
  all_data <- rbind(train_data, test_data)
  
  if(!is.factor(all_data[[feature]])){
    #breaks <- c(min(all_data[[feature]]),quantile(unique(all_data[[feature]]),probs = quantil_break), max(all_data[[feature]])+1)
    #lev <- names(bin_data(all_data, feature,))
    result_all <- bin_data(all_data, feature, return_breaks = TRUE)
    
    train_data <- bin_data(train_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(train_data) <- result_all$names
    test_data <- bin_data(test_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(test_data) <- result_all$names
    
    #Eliminate null bins
    train_data<-train_data[sapply(train_data, function(x) dim(x)[1]) > 0]
    test_data<-test_data[sapply(test_data, function(x) dim(x)[1]) > 0]
    
    train_data <- melt(train_data, measure.vars="error", value.name="error", variable.name="type")
    test_data <- melt(test_data, measure.vars="error", value.name="error", variable.name="type")
    train_data[[feature]]<- factor(train_data[["L1"]], levels=result_all$names) 
    test_data[[feature]] <- factor(test_data[["L1"]], levels=result_all$names)
  }
  
  test_data$type <- factor("Test", levels=c("Train", "Test"))
  train_data$type <- factor("Train", levels=c("Train", "Test"))
  test_data$total <- nrow(test_data)
  train_data$total <- nrow(train_data)
  
  all_data <- rbind(test_data, train_data)
  freq <- plyr::count(all_data, vars=c("type", feature))
  all_data <- merge(all_data, freq)

  errorplot <- ggplot(data=all_data, aes_string(x=feature, y="error", fill="type")) +
    xlab(feature) + ylab(paste0(error_type," Error Distribution")) +
    geom_boxplot() + guides(fill=FALSE) +
    geom_text(data=unique(all_data[c(x_feature, "type", "freq")]), aes(label=paste0("(",freq,")"), y=0-max(all_data$error)/15), vjust=1, size=3.2, position=position_dodge(0.9)) 
  
  allerror <- ggplot(data=all_data, aes(x='All Data', y=error, fill=type))+ xlab(" ") + geom_boxplot() + 
    scale_fill_discrete(name= "Data Set") +
    geom_text(data=unique(all_data[c("type","total")]), aes(label=paste0("(",total,")"), y=0-max(all_data$error)/15), vjust=1, size=3.2, position=position_dodge(0.9))  +
    theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank())  
  plot <- grid.arrange(errorplot, allerror, ncol=2, widths=c(nlevels(all_data[[feature]]), 1.8))
  
  return(plot)
   
}

metric_evaluation_edp <- function(train_data, test_data, feature, quantil_break=c(0.1, 0.35, 0.65, 0.9)){
  
  all_data <- rbind(train_data, test_data)
  result <- list()
  pval <- list()
  
  if(!is.factor(all_data[[feature]])){
    #breaks <- c(min(all_data[[feature]]),quantile(unique(all_data[[feature]]),probs = quantil_break), max(all_data[[feature]])+1)
    result_all <- bin_data(all_data, feature, return_breaks = TRUE, quantil_break=quantil_break)
    train_data <- bin_data(train_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(train_data) <- result_all$names
    test_data <- bin_data(test_data, feature, breaks=result_all$breaks, for_evaluation = TRUE) 
    names(test_data) <- result_all$names
    
    #Eliminate null bins
    train_data<-train_data[sapply(train_data, function(x) dim(x)[1]) > 0]
    test_data<-test_data[sapply(test_data, function(x) dim(x)[1]) > 0]
    # 
    train_data <- melt(train_data, measure.vars="error", value.name="error", variable.name="type")
    test_data <- melt(test_data, measure.vars="error", value.name="error", variable.name="type")
    train_data[[feature]]<- factor(train_data[["L1"]], levels=result_all$names) 
    test_data[[feature]] <- factor(test_data[["L1"]], levels=result_all$names)
    
  }else{
    result_all <- data.frame(names=levels(all_data[[feature]]))
  }
  
  for (bin in result_all$names){
    if(sum(train_data[[feature]]==bin) != 0 && sum(test_data[[feature]]==bin) != 0) {
      result[[bin]]<-ks.test(train_data[train_data[[feature]]==bin,][["error"]],test_data[test_data[[feature]]==bin,][["error"]])
      pval[["ks"]][[bin]]<-result[[bin]][["p.value"]]
      pval[["ad1"]][[bin]]<-ad.test(train_data[train_data[[feature]]==bin,][["error"]],test_data[test_data[[feature]]==bin,][["error"]])[["ad"]][1,3]
      pval[["ad2"]][[bin]]<-ad.test(train_data[train_data[[feature]]==bin,][["error"]],test_data[test_data[[feature]]==bin,][["error"]])[["ad"]][2,3]
      
    }else{
      pval[[bin]]<-NA
    }
    #result[[bin]]$alphalevel<- exp(-2*sum(train_data[[feature]]==bin)*sum(test_data[[feature]]==bin)*result[[bin]]$statistic[["D"]]^2/(sum(test_data[[feature]]==bin)+sum(train_data[[feature]]==bin)))#Null hypothesis is reject to alpha level (formula from "Critical Values for the Two sample Kolmogrov Smirvnov test, Montreal University)
    #the larger alpha level, the better? #VER LIVROS PARA CONFIRMAR ALPHA VS P VALUE
  }
  
  return(pval)
  
}




