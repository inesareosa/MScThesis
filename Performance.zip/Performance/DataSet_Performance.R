library(tibble)
library(caret) #For calculating feat Imp
library(rminer) # for calculating feat Imp with svm

source("performance_functions.R")

load("dataSetsWithPreds.Rdata")
load("DSAA/dataTestSet.Rdata")
load("DSAA/dataTrainSetswithPreds.Rdata")
names(DSsPreds) <- c('a1','a2','a3','a4','a6','a7','Abalone','acceleration','availPwr','bank8FM','cpuSm','fuelCons','boston','maxTorque','machineCpu','servo','airfoild','concreteStrength')
names(DStestOut) <- c('a1','a2','a3','a4','a6','a7','Abalone','acceleration','availPwr','bank8FM','cpuSm','fuelCons','boston','maxTorque','machineCpu','servo','airfoild','concreteStrength')
names(DStrainOut) <- c('a1','a2','a3','a4','a6','a7','Abalone','acceleration','availPwr','bank8FM','cpuSm','fuelCons','boston','maxTorque','machineCpu','servo','airfoild','concreteStrength')

nmod <- 4
err<-"Absolute"

#Models Comparative Analysis
for (err in c("Absolute", "Log")){
  for (j in 1:length(DSsPreds)) { 
    data_set  <- DSsPreds[[j]][complete.cases(DSsPreds[[j]]),]
    y_observed <- names(data_set)[1]
    error_ds <- all_model_data(data=data_set, models=names(data_set)[(length(data_set)-nmod+1):length(data_set)], feature_y = y_observed, type=err)
    
    plots1 <- list()
    for (i in 2:(ncol(data_set)-nmod)){
       x_feature <- names(data_set)[i]
       plots1[[i-1]]<-medp(error_ds, x_feature, mod_names=names(data_set)[(length(data_set)-nmod+1):length(data_set)], type=err)
    }
    g1 <- marrangeGrob(grobs=plots1, ncol=1, nrow=4)
    ggsave(paste0("Comparison/ModelsPerformance_",err,"_",names(DSsPreds)[[j]],".pdf"),g1,width=15,height=20)

    option=3
    comb<-combn(names(data_set[2:(length(data_set) - nmod)]),2)[,]
    plots3 <- list()
    for (c in 1:ncol(comb)) {
      plots3[[c]]<-biv_medp(error_ds, comb[,c], mod_names=names(data_set)[(length(data_set)-nmod+1):length(data_set)], type=err, option=option)
    }
  g1 <- marrangeGrob(grobs=plots3, ncol=1, nrow=2)
  ggsave(paste0("Comparison2D/2ModelsPerformance_",err,"_",names(DSsPreds)[[j]],".pdf"),g1,width=15,height=20)

  }
}

#Single Model Analysis
option="All"
for (j in 1:length(DSsPreds)) { 
  data_set  <- DSsPreds[[j]][complete.cases(DSsPreds[[j]]),]
  y_observed <- names(data_set)[1]
  for (mod in c("svm","randomForest", "nnet", "gbm")){
  
    single_error_ds <- single_model_data(data=data_set[1:(length(data_set) - nmod)], model=data_set[[mod]], feature_y=names(data_set)[1], type=err)
    
    plots1 <- pep(single_error_ds, alphaLines=0.7, type=err, option="B")
    ggsave(paste0("Parallel/",names(DSsPreds)[[j]],"_", mod,"Parallel",err,".pdf"),plots1,width=15,height=10)


    plots2 <- list()
    for (i in 2:(ncol(data_set)-nmod)){
      x_feature <- names(data_set)[i]
      plots2[[i-1]]<-edp(single_error_ds, x_feature, type=err, jitter=FALSE)
    }
    g1 <- marrangeGrob(grobs=plots2, ncol=2, nrow=4)
    ggsave(paste0("Single/",names(DSsPreds)[[j]],"_", mod,"Performance",err,".pdf"),g1,width=15,height=20)

    comb<-combn(names(data_set[2:(length(data_set) - nmod)]),2)[,]
    plots3 <- list()
    for (c in 1:ncol(comb)) {
       plots3[[c]]<-multiple_edp(single_error_ds, comb[,c], type=err, option='All', ncols=3, mode="wrap")
    }
    g2 <- marrangeGrob(grobs=plots3, ncol=1, nrow=2)
    ggsave(paste0("Single2D/2ModelsPerformance_",err,"_",names(DSsPreds)[[j]],"_",mod,".pdf"),g2,width=15,height=20)

  }
 
}

##Visual Evaluation
nmod <-4
for (j in 1:length(DSsPreds)) { 
  
  data_train  <- DStrainOut[[j]][complete.cases(DStrainOut[[j]]),]
  data_test  <- DStestOut[[j]][complete.cases(DStestOut[[j]]),] 
  y_observed <- names(data_train)[1]
  plots2 <- list()
  
  for (mod in c("svm","randomForest", "nnet", "gbm")){
    single_error_train <- single_model_data(data=data_train[1:(length(data_train) - nmod)], model=data_train[[mod]], feature_y=names(data_train)[1], type=err)
    single_error_test <- single_model_data(data=data_test[1:(length(data_test) - nmod)], model=data_test[[mod]], feature_y=names(data_test)[1], type=err)
    
     for (i in 2:(ncol(data_train)-nmod)){
       x_feature <- names(data_train)[i]
       plots2[[i-1]]<-evaluation_edp(single_error_train, single_error_test, x_feature, error_type=err)
       
     }
     g1 <- marrangeGrob(grobs=plots2, ncol=2, nrow=4)
     ggsave(paste0("SingleEvaluationNew/",names(DStrainOut)[[j]],"_", mod,"Evaluation",err,".pdf"),g1,width=15,height=20)
  }
  
}

#Metric Evaluation

library(plyr) #conflict in count with dplyr

all_pvalue <- vector("list", 18)
pars <- vector("list", 18)
for (j in 1:length(DSsPreds)) { 
  
  data_train  <- DStrainOut[[j]][complete.cases(DStrainOut[[j]]),]
  data_test  <- DStestOut[[j]][complete.cases(DStestOut[[j]]),] 
  y_observed <- names(data_train)[1]
  
  for (mod in c("svm","randomForest", "nnet", "gbm")){
    single_error_train <- single_model_data(data=data_train[1:(length(data_train) - nmod)], model=data_train[[mod]], feature_y=names(data_train)[1], type=err)
    single_error_test <- single_model_data(data=data_test[1:(length(data_test) - nmod)], model=data_test[[mod]], feature_y=names(data_test)[1], type=err)
    
    pars[[j]][[mod]] <- data.frame() #Metric = character(), Feature = character(), Max=double(), Min=double(), Med=double())
    for (i in 2:(ncol(data_train)-1-nmod)){
      x_feature <- names(data_train)[i]
      
      all_pvalue[[j]][[mod]][[x_feature]]<-metric_evaluation_edp(single_error_train, single_error_test, x_feature)
      # Max, Min and Median parameters of p value for each feature - first for ks, second two for ad
      # Global median of all points
      pars[[j]][[mod]] <- rbind(pars[[j]][[mod]], rownames_to_column(data.frame(Feature = x_feature, Max=sapply(all_pvalue[[j]][[mod]][[x_feature]], max), Min=sapply(all_pvalue[[j]][[mod]][[x_feature]], min), Med=sapply(all_pvalue[[j]][[mod]][[x_feature]], median)), "Metric"))
    }
    #Median as median of medians
    pars[[j]][[mod]]<-rbind(pars[[j]][[mod]], ddply(pars[[j]][[mod]], "Metric", summarize, Max=max(Max), Min=min(Min), Med=median(Med), Feature="All"))
   
  }
}
save(all_pvalue, file="kolmogorov_18dataset.Rdata")
save(pars, file="metrics_allparameters.Rdata")

#load("kolmogorov_18dataset.Rdata")
names(all_pvalue) <- names(DSsPreds)
pvalue <- melt(all_pvalue) %>% dplyr::rename(Test=L4, Feature=L3, Model=L2, Dataset=L1)
pvalue <- merge(pvalue, data.frame(Size=sapply(DSsPreds, nrow)))

Values<-unlist(all_pvalue)
val <- data.frame(Values = data.frame(Values), Row=names(Values))
val<-val[!is.na(val$Values),]
rownames(val) <- NULL
#library(tidyr)
val <- val %>% separate(Row, c("Dataset", "Model", "Feature", "Test", "Bin"), sep="[.]", extra="merge")

size <- data.frame()
for (j in 1:18){
  data_train  <- DStrainOut[[j]][complete.cases(DStrainOut[[j]]),]
  data_test  <- DStestOut[[j]][complete.cases(DStestOut[[j]]),] 
  y_observed <- names(data_train)[1]
  
  
  #Nota -1 est� errado!!!
  for (feat in colnames(data_train)[2:(ncol(data_train)-nmod-1)] ){
    a<- bincounter(data_train, data_test, feat)
    a <- cbind(a, data.frame(Dataset=names(DSsPreds)[j], Feature=colnames(a)[1]))
    colnames(a)[1] <- "Bin"
    size <- rbind(size, a)
    
  }
 
}

#size$Dataset <- mapvalues(size$Dataset, from =  c("a1" ,"a2" ,"a3","a4","a6" ,"a7" ,"Rings" ,"acceleration" ,"available.power","rej","usr", "fuel.consumption.country","HousValue","maximal.torque", "class","ScaledSoundPressure" ,"ConcreteCompressiveStrength"), to = names(DSsPreds)[-15])
pval <- merge(val, size)
save(pval, file="pvalues_wsize.Rdata")
pval$size<-0
pval<-pval[-which(pval[,"Test"]=="ad1"),]
pval[which(pval[,"Test"]=="ad2"),"Test"]<-"ad"

for (n in names(DSsPreds)){
  pval[["size"]][which(pval$Dataset==n)]<-nrow(DSsPreds[[n]])
}


pval$other <- factor(ifelse(pval$Values>0.05,"green", ifelse(pval$Values>0.01,"orange", "red")))
#ggplot(pval)+geom_bar(aes(x=factor(size), fill=other),position="fill") +facet_wrap(~Test)+xlab("Size of Dataset")+scale_fill_manual(name="P-value", labels=c(">0.05","0.01<...<0.05","<0.01"), values=c("green4","orange", "red"))+ylab("Percentage of Data set")
ggplot(pval)+geom_boxplot(aes(x=factor(size), y=Values, fill=Test)) #(xaxis, alfa lines)


## For all "Test"
b<-pval[which(pval[,"Test"]=="ad"),]
ggplot(b)+geom_histogram(aes(x=freq, fill=factor(other)), binwidth=100, position="fill") + xlab("Size of Bin")+scale_fill_manual(name="P-value", labels=c(">0.05","0.01<...<0.05","<0.01"), values=c("green"="green4","orange"="orange", "red"="red"))+ylab("Ratio of P-value") + facet_wrap(~Model) 
ggplot(b)+ geom_density(aes(x=Values, y=..count..), fill="darkblue", alpha=0.6)+ geom_vline(aes(xintercept=0.01), colour="red", linetype="dashed") + geom_vline(aes(xintercept=0.05), linetype="dashed", colour="yellow") + geom_vline(aes(xintercept=median(Values)), linetype="dashed", colour="black") + xlab("P-values") + ylab("Counts")
ggplot(b)+geom_density(aes(x=freq, y=..count.., fill=other), position="fill")  + xlab("Size of Dataset")+scale_fill_manual(name="P-value", labels=c(">0.05","0.01<...<0.05","<0.01"), values=c("green4","orange", "red"))+ylab("Percentage of Bins")



###NOTE: ORDERING PEP WITH FEAT IMPORTANCE

# library("gbm")
# j=7
# mod <- "gbm"
# data_set  <- DSsPreds[[j]][complete.cases(DSsPreds[[j]]),]
# y_observed <- names(data_set)[1]
# single_error_ds <- single_model_data(data=data_set[1:(length(data_set) - nmod)], model=data_set[[mod]], feature_y=names(data_set)[1], type=err)
# 
# model <- gbm(Rings ~ .,data=data_set[-c(10:14)], distribution="gaussian", n.trees=5000, interaction.depth=3)
# ord <- varImp(model, numTrees=5000)
# 
# ord <- rownames(ord[order(ord$Overall, decreasing=TRUE),, drop=FALSE])
# 
# single_error_ds <- cbind(single_error_ds[ord], single_error_ds[(ncol(single_error_ds)-1): ncol(single_error_ds)])
# 
# plots1 <- pep(single_error_ds, alphaLines=0.7, type=err, option="A")
# 
# ggsave(paste0("Parallel/Ord_",names(DSsPreds)[[j]],"_", mod,"Parallel",err,".pdf"),plots1,width=15,height=10)
#   
